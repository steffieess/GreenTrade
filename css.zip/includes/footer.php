<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>Contacto</h3>
            <a href="#"> <i class="fas fa-phone"></i>+56227895411 </a>
            <a href="#"> <i class="fas fa-phone"></i>+56227895411 </a>
            <a href="#"> <i class="fas fa-envelope"></i>equipogreentrade@greentrade.com </a>
        </div>

        <div class="box">
            <h3>Síguenos</h3>
            <a href="#"> <i class="fab fa-facebook-f"></i>GreenTrade </a>
            <a href="#"> <i class="fab fa-twitter"></i>@GreenTrade </a>
            <a href="#"> <i class="fab fa-instagram"></i>@GreenTrade </a>
        </div>

    </div>

    <div class="credit"> creado por <span>GreenTrade.cl</span> | todos los derechos reservados </div>

</section>
<!-- Scripts -->
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>

</html>